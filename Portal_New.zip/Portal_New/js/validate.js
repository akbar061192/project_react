function validate() {
  var Password = document.getElementById('password').value;
  if (Password == 'CAOneTechcloud') {
    window.alert('Succesfully Logged In');
    window.location.href = '../main.html';
  } else {
    window.alert('Password entered is wrong');
    return false;
  }
}

import React from 'react';
import './App.css';
import ind from './img/india.png';
import us from './img/united-states.png';
import eezy from './img/eezypost.png';
import eezyHire2 from './img/eezyhire-2.png';
import nurtureClient from './img/Nurture-CLient.png';
import nurtureClinic from './img/Nurture Clinic.png';
import ca from './img/CA-One.png';
import logo from './img/logo.png';

const App = () => {
  return (
    <div>
      <header className='uk-background-primary uk-background-norepeat uk-background-cover uk-background-center-center uk-light'>
        <nav className='uk-navbar-container'>
          <div className='uk-container'>
            <div data-uk-navbar style={{ display: 'flex' }}>
              <div className='uk-navbar-left uk-text-left'>
                <a className='uk-navbar-item uk-logo uk-visible@m' href='index.html'>
                  <img src={logo} alt='CA-One' />
                </a>
                <a className='uk-navbar-toggle uk-hidden@m' href='#offcanvas-docs' data-uk-toggle>
                  <span data-uk-navbar-toggle-icon></span> <span className='uk-margin-small-left'>Articles</span>
                </a>
              </div>
              <div className='uk-navbar-center uk-hidden@m'>
                <a className='uk-navbar-item uk-logo' href='index.html'>
                  <img src={logo} alt='CA-One' />
                </a>
              </div>
              <div className='uk-navbar-right'>
                <ul className='uk-navbar-nav uk-visible@m'>
                  <div className='uk-navbar-item'>
                    <a className='uk-button uk-button-primary-outline' href='#'>
                      Back to Website
                    </a>
                  </div>
                </ul>
                <a className='uk-navbar-toggle uk-hidden@m' href='#offcanvas' data-uk-toggle>
                  <span data-uk-navbar-toggle-icon></span> <span className='uk-margin-small-left'>Menu</span>
                </a>
              </div>
            </div>
          </div>
        </nav>
        <div
          class='uk-section uk-position-relative uk-position-z-index'
          data-uk-scrollspy='cls: uk-animation-slide-bottom-medium; repeat: true'
        >
          <div class='uk-container'>
            <h1 class='uk-text-center uk-margin-remove-top'>CA-One Portal</h1>
          </div>
        </div>
      </header>
      <div className='uk-section uk-section-muted'>
        <div className='uk-container'>
          <h2 className='uk-text-left uk-margin-remove-top uk-margin-large-bottom mb-2'>Tools</h2>
          <div className='uk-child-width-1-2@m uk-grid-match- uk-grid-small' data-uk-grid style={{ display: 'flex' }}>
            <div>
              <div className='uk-card uk-card uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded'>
                <div className='uk-grid-small' data-uk-grid>
                  <div className='uk-width-auto uk-text-primary uk-flex uk-flex-middle '>
                    <img src={ind} alt='CA-One' width='15%' />
                  </div>
                  <div>
                    <h3 className='uk-card-title uk-margin-remove uk-text-primary'>CRM India</h3>
                    <p className='uk-text-muted uk-margin-remove'>
                      Get started fast with installation and theme setup instructions.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className='uk-card uk-card uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded'>
                <div className='uk-grid-small' data-uk-grid>
                  <div className='uk-width-auto uk-text-primary uk-flex uk-flex-middle'>
                    <img src={us} alt='CA-One' width='15%' />
                  </div>
                  <div>
                    <h3 className='uk-card-title uk-margin-remove uk-text-primary'>CRM US</h3>
                    <p className='uk-text-muted uk-margin-remove'>
                      Get started fast with installation and theme setup instructions.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className='uk-section uk-section-muted'>
        <div className='uk-container'>
          <h2 className='uk-text-left uk-margin-remove-top uk-margin-large-bottom mb-2'>Products</h2>
          <div
            className='uk-child-width-1-2@m uk-grid-match- uk-grid-small'
            data-uk-grid
            style={{ display: 'flex', flexWrap: 'wrap' }}
          >
            <div>
              <div
                className='uk-card uk-card uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded'
                style={{ marginBottom: '28px' }}
              >
                <div className='uk-grid-small' data-uk-grid>
                  <div className='uk-text-primary '>
                    <img src={eezy} alt='CA-One' />
                  </div>
                  <div>
                    <h3 className='uk-card-title uk-text-primary'>Ezy Post</h3>
                    <p className='uk-text-muted '>
                      EezyPost is a newer and quicker platform, helping people to find jobs in their dream sectors with
                      ease. If you are looking for a new job, you can sign up on EezyPost and they will do the rest
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className='uk-card uk-card uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded'>
                <div className='uk-grid-small' data-uk-grid>
                  <div className='uk-text-primary '>
                    <img src={eezyHire2} alt='CA-One' />
                  </div>
                  <div>
                    <h3 className='uk-card-title uk-text-primary'>Ezy Hire</h3>
                    <p className='uk-text-muted '>
                      Payroll and Hiring Offshore Resources in India, Using our Intelligent Talent Cloud, we help you
                      hire, vet, manage, and match the best offshore resources in India.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className='uk-card uk-card uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded'>
                <div className='uk-grid-small' data-uk-grid>
                  <div className='uk-text-primary '>
                    <img src={nurtureClient} alt='CA-One' />
                  </div>
                  <div>
                    <h3 className='uk-card-title uk-text-primary'>Nurture Client</h3>
                    <p className='uk-text-muted '>
                      We are a digital marketing agency based in silicon valley, San Francisco, striving to achieve the
                      best digital marketing results for your company.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div
                className='uk-card uk-card uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded'
                style={{ marginBottom: '28px' }}
              >
                <div className='uk-grid-small' data-uk-grid>
                  <div className='uk-text-primary '>
                    <img src={nurtureClinic} alt='CA-One' />
                  </div>
                  <div>
                    <h3 className='uk-card-title uk-text-primary'>Nurture Clinic</h3>
                    <p className='uk-text-muted '>
                      Our cloud-based, EHR Management System Provides solutions for small to large clinics, hospitals,
                      or multi-specialty healthcare centers.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className='uk-card uk-card uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded'>
                <div className='uk-grid-small' data-uk-grid>
                  <div className='uk-text-primary '>
                    <img src={nurtureClient} alt='CA-One' />
                  </div>
                  <div>
                    <h3 className='uk-card-title uk-text-primary'>Nurture Mail</h3>
                    <p className='uk-text-muted '>
                      Email marketing platform that drives revenue!Create beautiful, branded emails that make you look
                      like a pro.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className='uk-card uk-card uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded'>
                <div className='uk-grid-small' data-uk-grid>
                  <div className='uk-text-primary '>
                    <img src={ca} alt='CA-One' />
                  </div>
                  <div>
                    <h3 className='uk-card-title uk-text-primary'>Component Library</h3>
                    <p className='uk-text-muted '>Get started fast with installation and theme setup instructions.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className='uk-section uk-section-muted'>
        <div className='uk-container'>
          <div className='row'>
            <div className='col-md-12'>
              <div className='card'>
                <div className='card-body'>
                  <h2 className='uk-text-left uk-margin-remove-top uk-margin-large-bottom mb-2 card-title'>
                    Announcements
                  </h2>
                  <div id='content'>
                    <ul className='timeline'>
                      <li className='event' data-date='25-05-2022'>
                        <h3>Eezy Post Launch</h3>
                        <p>
                          EezyPost is a newer and quicker platform, helping people to find jobs in their dream sectors
                          with ease. If you are looking for a new job, you can sign up on EezyPost and they will do the
                          rest
                        </p>
                      </li>
                      <li className='event' data-date='25-05-2022'>
                        <h3>Eezy Hire Launch</h3>
                        <p>
                          Payroll and Hiring Offshore Resources in India, Using our Intelligent Talent Cloud, we help
                          you hire, vet, manage, and match the best offshore resources in India.
                        </p>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className='uk-section uk-section-muted'>
        <div className='uk-container'>
          <h2 className='uk-text-left uk-margin-large-bottom'>Messages From CEO</h2>
          <div>
            <div className='uk-card uk-card uk-card-default uk-card-hover uk-card-body uk-block uk-border-rounded'>
              <a className='uk-position-cover' href='#'></a>
              <div className='uk-grid-small' data-uk-grid style={{ display: 'flex' }}>
                <div className='uk-width-auto uk-text-primary uk-flex uk-flex-middle'>
                  <img
                    className='uk-avatar uk-border-circle'
                    src='https://nurtureclient.com/wp-content/uploads/2021/10/rajul.jpg'
                    alt='CEO'
                  />
                </div>
                <div className='uk-width-expand uk-flex-middle'>
                  <h3 className='uk-card-title uk-text-primary '>Rajul</h3>
                  <p className='uk-text-muted uk-margin-remove'>
                    {' '}
                    Get started fast with installation and theme setup instructions.Get started fast with installation
                    and theme setup instructions.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div id='offcanvas' data-uk-offcanvas='flip: true; overlay: true'>
        <div className='uk-offcanvas-bar'>
          <a className='uk-logo' href='#'>
            Guia
          </a>
          <button className='uk-offcanvas-close' type='button' data-uk-close></button>
          <div className='uk-margin-top uk-text-center'>
            <div data-uk-grid className='uk-child-width-auto uk-grid-small uk-flex-center'>
              <div>
                <a
                  href='https://twitter.com/'
                  data-uk-icon='icon: twitter'
                  className='uk-icon-link'
                  target='_blank'
                ></a>
              </div>
              <div>
                <a
                  href='https://www.facebook.com/'
                  data-uk-icon='icon: facebook'
                  className='uk-icon-link'
                  target='_blank'
                ></a>
              </div>
              <div>
                <a
                  href='https://www.instagram.com/'
                  data-uk-icon='icon: instagram'
                  className='uk-icon-link'
                  target='_blank'
                ></a>
              </div>
              <div>
                <a href='https://vimeo.com/' data-uk-icon='icon: vimeo' className='uk-icon-link' target='_blank'></a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <footer className='uk-section uk-text-center uk-text-muted'>
        <div className='uk-container uk-container-small'>
          <div className='uk-margin-medium'>
            <div data-uk-grid className='uk-child-width-auto uk-grid-small uk-flex-center'>
              <div className='uk-first-column'>
                <a
                  href='https://twitter.com/'
                  data-uk-icon='icon: twitter'
                  className='uk-icon-link uk-icon'
                  target='_blank'
                ></a>
              </div>
              <div>
                <a
                  href='https://www.facebook.com/'
                  data-uk-icon='icon: facebook'
                  className='uk-icon-link uk-icon'
                  target='_blank'
                ></a>
              </div>
              <div>
                <a
                  href='https://www.instagram.com/'
                  data-uk-icon='icon: instagram'
                  className='uk-icon-link uk-icon'
                  target='_blank'
                ></a>
              </div>
              <div>
                <a
                  href='https://vimeo.com/'
                  data-uk-icon='icon: vimeo'
                  className='uk-icon-link uk-icon'
                  target='_blank'
                ></a>
              </div>
            </div>
          </div>
          <div className='uk-margin-medium uk-text-small uk-link-muted'>
            Made by <a href='https://ca-one.com/'>CA-One Tech Cloud Inc.</a> Team.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
